package 출력문;

public class Test01 {
	public static void main(String[] args) {
		// print는 줄바꿈을 안함
		System.out.print("Hello World");
		System.out.print("Java");
	}
}
