package 변수;

public class StringType {

	public static void main(String[] args) {
		//String은 문자열을 저장
		String a = "Hello Java World";
		
		System.out.println(a);

	}

}
