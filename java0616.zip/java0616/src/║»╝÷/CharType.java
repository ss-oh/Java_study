package 변수;

public class CharType {

	public static void main(String[] args) {
		//char는 한 글자인 문자를 저장
		char a = 'A'; // 문자열 쌍따옴표, 문자는 작은따옴표
		int num;
		
		
		System.out.println(a);
		
		num = a;
		
		System.out.println(num);

	}

}
