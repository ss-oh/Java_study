package 변수;

public class BooleanType {

	public static void main(String[] args) {

		//boolean은 true와 false만 저장 가능
		boolean a = true;
		boolean b = false; // true와 false에는 따옴표 하면 안됨
		
		System.out.println(" a : " + a + " b : " + b);

	}

}
