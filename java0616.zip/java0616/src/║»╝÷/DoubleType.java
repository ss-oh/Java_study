package 변수;

public class DoubleType {

	public static void main(String[] args) {

		float a = 3.14f;
		double b = 123.456;
		
		System.out.println(a);
		System.out.println(b);

	}

}
