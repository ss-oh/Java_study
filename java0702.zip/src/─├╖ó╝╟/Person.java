package 컬랙션;

public class Person {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
