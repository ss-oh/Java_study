package 컬랙션;

public class CafeMenu {
	String name;
	int price;
	String category;
	public CafeMenu(String name, int price, String category) {
		
		this.name = name;
		this.price = price;
		this.category = category;
	}
	
	
}
