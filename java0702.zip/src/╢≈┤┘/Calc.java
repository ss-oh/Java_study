package 람다;

@FunctionalInterface
public interface Calc {
	int sum(int a, int b);
	
}
