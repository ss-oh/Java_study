package 연습;

public class Student {
	String name;
	String subjects;
	int score;
	
	Student(String name){
		this.name = name;
	}
	
	
}
