package 생성자;

public class CarMain {

	public static void main(String[] args) {
		
		Car taxi = new Car("소나타","빨강",2000);
		Car bus = new Car("d","d",2000);
		//초기값을 설정할 때는 생정자를 통해 세팅
		
	}

}
