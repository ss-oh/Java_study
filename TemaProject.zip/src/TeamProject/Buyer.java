package TeamProject;

public class Buyer {
}
