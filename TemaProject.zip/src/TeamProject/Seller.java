package TeamProject;

public class Seller {

}
