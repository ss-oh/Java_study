package TeamProject;

public class MemberManager {

}
