package TeamProject;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import TeamProject.Product;
import TeamProject.Drink;
import TeamProject.Cloth;
import TeamProject.Cosmetic;

public class ShoppingMallMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		List<Cloth> cloth = new ArrayList<>();
		
		cloth.add(new Cloth(30000, 10, 101, "티셔츠"));
        cloth.add(new Cloth(45000, 5, 102, "청바지"));
        cloth.add(new Cloth(60000, 3, 103, "재킷"));
        
        for (Cloth c : cloth) {
            c.showInfo(); // showInfo 메서드를 Cloth 클래스에 구현해야 함
        }
        
		List<Drink> drink = new ArrayList<>();
		
		drink.add(new Drink(30000, 10, 101, "콜라"));
		drink.add(new Drink(4500, 5, 102, "사이다"));
		drink.add(new Drink(7000, 3, 103, "환타"));
        
        for (Drink d : drink) {
            d.showInfo(); // showInfo 메서드를 Cloth 클래스에 구현해야 함
        }
        
		List<Cosmetic> cosmetic = new ArrayList<>();
		
		cosmetic.add(new Cosmetic(30000, 10, 101, "스킨"));
		cosmetic.add(new Cosmetic(400, 5, 102, "로션"));
		cosmetic.add(new Cosmetic(6001, 3, 103, "립밤"));
        
        for (Cosmetic cl : cosmetic) {
            cl.showInfo(); // showInfo 메서드를 Cloth 클래스에 구현해야 함
        }
		
		
		

	}

}
