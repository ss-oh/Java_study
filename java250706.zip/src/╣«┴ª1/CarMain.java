package 문제1;

public class CarMain {

	public static void main(String[] args) {
		Car car = new Car();
		car.setBrand("테슬라");
		car.setModel("X");
		car.setMaxSpeed(200);		
		
		car.printInfo();

	}

	}
