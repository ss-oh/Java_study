package 문제2;

public class Man extends Employee {
	
	public Man(String name, int salary, String department) {
		super(name, salary, department);
	}
}
