package 문제3;

public class EmployeeManagement {
	
	public static void main(String[] args) {
		Employee[] person = {
				new Manager("John", 5000),
				new Engineer("Emily", 3000),
				new Manager("David", 2000),
				new Salesperson("Sarah", 4000)		
		};
		
		
	}
}
// Q. 전체적인 메인코드 확인필요